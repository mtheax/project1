using RefactoredCommandSystem;
using RefactoredCommandSystem.Loaders;
using RefactoredCommandSystem.Services;

var game = new Game(new JsonCommandLoader("commands.json"), new CommandExecutor());
game.Start();