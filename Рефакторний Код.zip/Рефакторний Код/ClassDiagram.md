# UML — Class diagram (PlantUML) and explanations

```plantuml
@startuml
package RefactoredCommandSystem {
    class Game {
        - ICommandLoader _loader
        - CommandExecutor _executor
        + Start()
    }

    interface ICommandLoader {
        + LoadCommands()
        + SaveCommand(Command)
    }

    class JsonCommandLoader {
        - string _filePath
        + LoadCommands()
        + SaveCommand(Command)
    }

    class CommandExecutor {
        - List<Command> _commands
        + SetCommands(IEnumerable<Command>)
        + ExecuteAll()
        + ExecuteByName(string)
    }

    abstract class Command {
        - string Name
        + Execute()
    }

    class PrintCommand {
        - string Message
        + Execute()
    }

    Game --> ICommandLoader
    Game --> CommandExecutor
    ICommandLoader <|-- JsonCommandLoader
    CommandExecutor --> Command
    Command <|-- PrintCommand
}
@enduml
```

## Roles and interactions

- **Game**: orchestrates the flow. It depends on the loader to obtain commands and on the executor to run them.
- **ICommandLoader**: abstraction for persistence. Implementations (like `JsonCommandLoader`) perform loading/saving of commands.
- **JsonCommandLoader**: concrete loader. Responsible solely for mapping persistence (JSON) to domain `Command` objects.
- **CommandExecutor**: executes `Command` objects. It receives list of commands and provides methods to run them all or by name.
- **Command** (abstract): represents an action. Provides `Execute()` contract; concrete commands (e.g., `PrintCommand`) implement the behavior.
- **PrintCommand**: simple implementation that prints a message to the console.

The design follows Single Responsibility Principle: persistence, execution, and orchestration are separated.